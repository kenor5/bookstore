import React from "react";
import Home from "./home";
import Login from "./login";


export default class Index extends React.Component{

  render() {
    return (
      <Home/>
    )
  }
}

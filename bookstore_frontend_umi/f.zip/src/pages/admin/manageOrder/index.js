import React from "react";
import "../../bookDetail/bookDetail.css"
import {Layout, Badge, Dropdown, Menu, Space, Table} from "antd";
import {history} from 'umi';
import { DownOutlined } from '@ant-design/icons';
import {getBook, getBookName, updateBook} from "../../../service/bookService";
import AdminMenu from "../../../components/adminMenu";
import {getOrders} from "../../../service/orderService";


const { Header, Content, Sider } = Layout;

const menu = (
  <Menu
    items={[
      {
        key: '1',
        label: 'Action 1',
      },
      {
        key: '2',
        label: 'Action 2',
      },
    ]}
  />
);



export default class ManageBook extends React.Component{

  constructor(props) {
    super(props);
    this.state = {
      source:[]
    };
  }

  init() {

    if (localStorage.getItem('user') == null) {
      history.push('/login');
    }
    console.log(history.location.state)
    const callback = (data) => {
      this.setState({
        source: data
      });
      console.log(data);
    }

    getOrders(callback);
  }

  componentDidMount () {
    this.init();
  }

  render() {

    const expandedRowRender = (ele) => {
      console.log(ele.key);
      const columns = [
        {
          title: '书id',
          dataIndex: 'book_id',
          key: 'book_id',
        },
        {
          title: '数量',
          dataIndex: 'book_num',
          key: 'book_num',
        },

      ];
      const data = [];

      for (let i = 0; i < this.state.source[ele.key].length; ++i) {
        data.push(this.state.source[ele.key][i]);
      }


      // for (let i = 0; i < data.length; ++i) {
      //
      //   let callback1 = (val) => {
      //     data[i].book_name = val;
      //   }
      //   if (i === data.length - 1) {
      //     await callback1 = (val) => {
      //       data[i].book_name = val;
      //     }
      //     getBookName(data[i].book_id, callback1);
      //   } else getBookName(data[i].book_id, callback1);
      //
      // }


      return <Table columns={columns} dataSource={data} pagination={false}/>;

    };

    const columns = [
      {
        title: '订单编号',
        dataIndex: 'order_id',
        key: 'order_id',
      },

    ];
    const data = [];

    for (let i = 0; i < this.state.source.length; ++i) {
      data.push({
        key: i,
        order_id:i,
      });
    }
    return(
      <Layout>
        <Header className="header">
          <div className="logo" />
          {/*<Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']} items={items1} />*/}
        </Header>
        <Content
          style={{
            padding: '0 50px',
            width: '1200px',
            alignSelf:"center",
            height:"93vh"
          }}
        >

          <Layout
            className="site-layout-background"
            style={{
              padding: '24px 0',
            }}
          >
            <Sider className="site-layout-background" theme={'light'} width={200}>

              <AdminMenu/>
            </Sider>

            <Content
              style={{
                padding: '0 24px',
                minHeight: 280,
              }}
            >

              <Table
                className="components-table-demo-nested"
                columns={columns}
                expandable={{
                  expandedRowRender,
                }}
                dataSource={data}
              />



            </Content>
          </Layout>
        </Content>

      </Layout>

    );
  }

}

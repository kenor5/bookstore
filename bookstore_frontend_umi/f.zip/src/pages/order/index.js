import React from "react";
import { Layout} from "antd";
import { Table, Tag, Space } from 'antd';
import MyMenu from "../../components/menu";
import {history} from "../../.umi/core/history";

const { Header, Content, Sider } = Layout;


const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    render: (text, record) => <a onClick={()=>{
      history.push({
        pathname: '/bookDetail',
        state: {
          src: record.book_id
        }
      });
    }
    }>{text}</a>,
  },
  {
    title: 'Author',
    dataIndex: 'author',
    key: 'author',
  },
  {
    title: 'Price',
    dataIndex: 'price_after',
    key: 'price_after',
  },
  {
    title: 'Num',
    dataIndex: 'book_num',
    key: 'book_num',
  }

];


export default class Order extends React.Component{

  constructor(props) {
    super(props);
  }
  componentDidMount() {
    if (localStorage.getItem('user') == null) {
      history.push('/login');
    }}

  render() {
    return(
      <Layout>
        <Header className="header">
          <div className="logo" />
          {/*<Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']} items={items1} />*/}
        </Header>
        <Content
          style={{
            padding: '0 50px',
            width: '1200px',
            alignSelf:"center",
            height:"93vh"
          }}
        >

          <Layout
            className="site-layout-background"
            style={{
              padding: '24px 0',
              height:"90vh"
            }}
          >
            <Sider className="site-layout-background" theme={'light'} width={200}>

              <MyMenu/>
            </Sider>
            <Content
              style={{
                padding: '0 24px',
                minHeight: 280,
              }}
            >
              <Table columns={columns} dataSource={data} />

            </Content>
          </Layout>
        </Content>

      </Layout>

    );
  }

}

import {axios} from "../utils/axios";
import {message} from "antd";
import {history} from 'umi';
import qs from "qs";


export const getBooks = (callback) => {
  axios({
    method: 'GET',
    url: 'http://localhost:8080/getBooks',
    params: {
    }
  }).then(response => {
    // console.log(response.data);
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const getBook = (book_id, callback) => {

  axios({
    method: 'GET',
    url: 'http://localhost:8080/getBook',
    params: {
      book_id:book_id
    }
  }).then(response => {
    // console.log(response.data);
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const updateBook = (values,book_id, callback) => {

  axios({
    method: 'POST',
    url: 'http://localhost:8080/updateBook',
    params: {
      book_id:book_id,
      name:(values.name === undefined || values.name === "") ? "!": values.name,
      type:values.type === "" || values.type === undefined? "!": values.type,
      author:values.author === undefined  || values.author === ""? "!": values.author,
      price_after:values.price_after === undefined || values.price_after === ""? "!": values.price_after,
      description:values.description === undefined || values.description === ""? "!": values.description
    }
  }).then(response => {
    // console.log(response.data);
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const getBookByIds = (data, callback) => {
  let params = {book_ids:data};
  axios({
    method: 'GET',
    url: 'http://localhost:8080/getBookByIds',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }

  }).then(response => {
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const getBookName = (id, callback1) => {
  const callback = (val) => {
    callback1(val.name);
  }
  getBook(id, callback);
}



import {axios} from "../utils/axios";
import {message} from "antd";
import {history} from 'umi';


export const login = (data) => {
  axios({
    method: 'GET',
    url: 'http://localhost:8080/checkUser',
    params: {
      username: data.username,
      password: data.password,
      userType: data.userType === 'user' ? 1 : 0,
    }
  }).then(response => {
    console.log(response)
    if (response.status === 200) {
      localStorage.setItem('user', JSON.stringify(response.data));
      if (data.userType === 'admin')
        history.push("/admin");
      else
        history.push("/");

    }
    message.success("登陆成功")
  }).catch(error => {
    console.log(error)
    message.error("账号或密码错误");
  })
}

export const logout = () => {
      localStorage.removeItem("user");
      history.push("/login");
};

export const getUsers = (callback) => {
  axios({
    method: 'GET',
    url: 'http://localhost:8080/getUsers',
    params: {
    }
  }).then(response => {
    console.log(response)
    callback(response.data);
  }).catch(error => {
    console.log(error)
  })
}

export const updateUser = (values, callback) => {
  if(values.user_id === undefined || values.user_id === "") return;
  axios({
    method: 'GET',
    url: 'http://localhost:8080/updateUser',
    params: {
      user_id: values.user_id,
      username:(values.username === "" || values.username === undefined)? "!": values.username,
      password:(values.password === "" || values.password === undefined)? "!": values.password
    }
  }).then(response => {
    console.log(response);
    callback();
  }).catch(error => {
    console.log(error)
  })
}



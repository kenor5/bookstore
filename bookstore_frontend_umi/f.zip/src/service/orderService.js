import {axios} from "../utils/axios";
import {message} from "antd";
import {history} from 'umi';
import qs from "qs";

export const getOrder = (data, callback) => {
  axios({
    method: 'GET',
    url: 'http://localhost:8080/getOrder',
    params: {
      user_id:data
    }
  }).then(response => {
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const getOrders = (callback) => {
  axios({
    method: 'GET',
    url: 'http://localhost:8080/getOrders',

  }).then(response => {
    callback(response.data);
  }).catch(error => {
    console.log(error);
  })
}

export const addToOrder = (data, user_id, callback) => {
  let book_ids = [], book_nums = [];
  for (const i in data) {
    book_ids.push(data[i].book_id);
    book_nums.push(data[i].book_num);
  }
  let params = {book_ids:book_ids, book_nums:book_nums, user_id: user_id};
  axios({
    method: 'GET',
    url: 'http://localhost:8080/addToOrder',
    params,
    paramsSerializer: params => {
      return qs.stringify(params, {
        indices: false
      })
    }
  }).then(response => {
    callback();
    message.success("成功");
  }).catch(error => {
    console.log(error);
  })
}

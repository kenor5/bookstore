import "./singleBook.css"
import {history} from 'umi';

export default function SingleBook(props) {
  return (
    <li onClick={()=>{
      let pathname;
      console.log((JSON.parse(localStorage.getItem('user'))));
      if (JSON.parse(localStorage.getItem('user')).user_type === 1)
        pathname = '/bookDetail';
      else
        pathname = '/admin/manageBook';

      history.push({
        pathname: pathname,
        state: {
          src: props.src.book_id
        }
      });

    }}>
      <div className="pro-img">
        <a href="#">
            <img src={props.src.image} alt=""/>

        </a>
      </div>
      <h3><a href="#">{props.src.name}</a></h3>
      <p className="desc">{props.src.author}</p>
      <p className="price">
        <span>{props.src.price_before}</span>元
        <del>{props.src.price_after}</del>
      </p>
      <div className="review">
        <a href="#">
          <span className="cmt">some comment</span>
          <span className="cmt-id"> kenor</span>
        </a>
      </div>
    </li>

  );

}

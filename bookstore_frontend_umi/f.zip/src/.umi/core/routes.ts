// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'D:/WORKS/THI_2/web/bookstore_frontend_umi/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": require('@/pages/index').default,
    "exact": true
  },
  {
    "path": "/home",
    "component": require('@/pages/home').default,
    "exact": true
  },
  {
    "path": "/login",
    "component": require('@/pages/login').default,
    "exact": true
  },
  {
    "path": "/bookDetail",
    "component": require('@/pages/bookDetail').default,
    "exact": true
  },
  {
    "path": "/cart",
    "component": require('@/pages/cart').default,
    "exact": true
  },
  {
    "path": "/order",
    "component": require('@/pages/order').default,
    "exact": true
  },
  {
    "path": "/profile",
    "component": require('@/pages/profile').default,
    "exact": true
  },
  {
    "path": "/admin",
    "component": require('@/pages/admin').default,
    "exact": true
  },
  {
    "path": "/admin/manageBook",
    "component": require('@/pages/admin/manageBook').default,
    "exact": true
  },
  {
    "path": "/admin/manageOrder",
    "component": require('@/pages/admin/manageOrder').default,
    "exact": true
  },
  {
    "path": "/admin/manageUser",
    "component": require('@/pages/admin/manageUser').default,
    "exact": true
  },
  {
    "path": "/admin/statistics",
    "component": require('@/pages/admin/statistics').default,
    "exact": true
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
